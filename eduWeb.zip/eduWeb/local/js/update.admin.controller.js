app.controller("updateController",['$scope','$http','adminAPI',updateController]);

function updateController($scope,$http,adminAPI)
{
	$scope.searchData = function()
	{
		var keyword = document.getElementById("keyword").value;
		var table = document.getElementById("tableselect").value;
		adminAPI.searchResult(keyword,table,function(data){
			if(data.length == 0)
			{
				$scope.noresAlert = "No result found"
			}
			else{
				$scope.noresAlert = "";
				document.getElementById('restable').style.display = "inline-table";
				document.getElementById('buttonset').style.display = "block";
				$scope.keys = [];
				$scope.jsondata = [];
				for(var i=0;i<Object.keys(data[0]).length;i++)
				{
					if(Object.keys(data[0])[i].substring(0,1)!="_")
					{
						$scope.keys.push(Object.keys(data[0])[i])
						$scope.jsondata.push(data[0][Object.keys(data[0])[i]])
					}
				}
			}
			console.log(data);
		});
	}
}

